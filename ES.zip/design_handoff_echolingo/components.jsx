/* ============ Echolingo — shared components ============ */
const { useState, useRef, useEffect, useCallback } = React;

/* top app bar */
function AppBar({ title, onHome, onNew }) {
  return (
    <div className="bar">
      <div className="bar__home">
        <button className="wordmark" onClick={onHome} aria-label="home">
          echolingo<span className="dot">.</span>
        </button>
      </div>
      <div className="bar__title">
        {title && <div className="bar__title-text">{title}</div>}
      </div>
      <div className="bar__action">
        {onNew && (
          <button className="btn-new" onClick={onNew}>
            <span className="plus">+</span> new
          </button>
        )}
      </div>
    </div>
  );
}

/* custom language dropdown */
function Select({ value, onChange, disabledValue }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  useEffect(() => {
    if (!open) return;
    const h = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener('mousedown', h);
    return () => document.removeEventListener('mousedown', h);
  }, [open]);
  return (
    <div className="select" ref={ref}>
      <button className="select__btn" onClick={() => setOpen(o => !o)}>
        <span>{value}</span>
        <span className="select__chev">{Ic.chevDown(18)}</span>
      </button>
      {open && (
        <div className="menu">
          {LANGUAGES.map(l => (
            <div
              key={l}
              className={'menu__item' + (l === value ? ' is-active' : '') + (l === disabledValue ? ' is-disabled' : '')}
              onClick={() => { if (l !== disabledValue) { onChange(l); setOpen(false); } }}
            >
              <span>{l}</span>
              {l === value && Ic.check(16)}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* the create form — compact on the home surface, full for first-run hero */
function CreateForm({ prefs, setPrefs, onGo, compact }) {
  const taRef = useRef(null);
  const autosize = () => {
    const ta = taRef.current;
    if (!ta) return;
    ta.style.height = 'auto';
    ta.style.height = ta.scrollHeight + 'px';
  };
  useEffect(() => { autosize(); }, [prefs.topic, compact]);

  const set = (k, v) => setPrefs(p => ({ ...p, [k]: v }));

  // language auto-swap to avoid collision (no manual swap button)
  const setSpeak = (v) => setPrefs(p => ({ ...p, speak: v, learning: v === p.learning ? p.speak : p.learning }));
  const setLearning = (v) => setPrefs(p => ({ ...p, learning: v, speak: v === p.speak ? p.learning : p.speak }));

  const fillPct = ((prefs.level - 1) / (LEVELS.length - 1)) * 100;
  const mb = 18;

  return (
    <div>
      {/* topic — can be long / multiline */}
      <div className="section-pad" style={{ marginBottom: mb }}>
        <textarea
          ref={taRef}
          className="topic"
          rows={1}
          value={prefs.topic}
          placeholder={'at the bakery, ordering coffee, asking the barista what they recommend…'}
          onChange={(e) => set('topic', e.target.value)}
          onInput={autosize}
        />
      </div>

      {!compact && (
        <div className="section-pad" style={{ marginBottom: mb }}>
          <div className="chips">
            {SUGGESTIONS.map(s => (
              <button key={s} className="chip" onClick={() => set('topic', s)}>{s}</button>
            ))}
          </div>
        </div>
      )}

      <div className="divider" style={{ marginBottom: mb }} />

      {/* languages */}
      <div className="section-pad" style={{ marginBottom: mb }}>
        <div className="lang-grid">
          <div>
            <label className="label">I speak</label>
            <Select value={prefs.speak} onChange={setSpeak} disabledValue={prefs.learning} />
          </div>
          <div>
            <label className="label">learning</label>
            <Select value={prefs.learning} onChange={setLearning} disabledValue={prefs.speak} />
          </div>
        </div>
      </div>

      {/* length */}
      <div className="section-pad" style={{ marginBottom: mb }}>
        <label className="label">length</label>
        <div className="pills">
          {[5, 10, 20, 30].map(m => (
            <button key={m} className={'pill' + (prefs.minutes === m ? ' is-on' : '')}
              onClick={() => set('minutes', m)}>{m} min</button>
          ))}
        </div>
      </div>

      {/* level (CEFR) */}
      <div className="section-pad" style={{ marginBottom: mb }}>
        <label className="label">level · {cefr(prefs.level)}</label>
        <div className="range-wrap">
          <input
            type="range" className="range" min="1" max={LEVELS.length} step="1"
            value={prefs.level}
            onChange={(e) => set('level', +e.target.value)}
            style={{ background: `linear-gradient(to right, var(--accent) ${fillPct}%, var(--line) ${fillPct}%)` }}
          />
          <div className="ticks">
            {LEVELS.map(l => (
              <span key={l.n} className={prefs.level === l.n ? 'is-on' : ''}>{l.code}</span>
            ))}
          </div>
        </div>
      </div>

      {/* go */}
      <div className="section-pad" style={{ display: 'flex', justifyContent: 'center', paddingTop: 4, paddingBottom: 4 }}>
        <button className="go" disabled={!prefs.topic.trim()} onClick={onGo}>
          go {Ic.arrowRight(18)}
        </button>
      </div>
    </div>
  );
}

Object.assign(window, { AppBar, Select, CreateForm });
