/* ============ Echolingo — Home screen ============ */

function ProgressRing({ p }) {
  const r = 21, c = 2 * Math.PI * r;
  return (
    <svg className="ring-prog" width="44" height="44" viewBox="0 0 44 44">
      <circle cx="22" cy="22" r={r} fill="none" stroke="var(--aegean)" strokeWidth="2"
        strokeDasharray={c} strokeDashoffset={c * (1 - p)} strokeLinecap="round" />
    </svg>
  );
}

function EchoRow({ echo, onOpen }) {
  const done = echo.progress >= 1;
  const partial = echo.progress > 0 && echo.progress < 1;
  const isNew = echo.progress === undefined || echo.progress === 0;
  return (
    <div className="echo-row" onClick={() => onOpen(echo)}>
      <div className="echo-row__play">
        {partial && <ProgressRing p={echo.progress} />}
        {Ic.play(18)}
      </div>
      <div className="echo-row__body">
        <div className="echo-row__title">{echo.title}</div>
        <div className="echo-row__meta">
          <span className="lang">{echo.learning}</span> · {echo.minutes} min · {cefr(echo.level)}
          {done ? ' · finished' : ''} · {echo.ago}
        </div>
      </div>
      {isNew && <span className="dot-new" />}
    </div>
  );
}

function Home({ prefs, setPrefs, onGo, onOpenEcho, onHome, onNew, library, firstRun }) {
  return (
    <div className="app">
      <AppBar onHome={onHome} />
      <div>
        {firstRun ? (
          <div className="hero fade" style={{ paddingTop: 24, paddingBottom: 18 }}>
            <h1 className="hero__h">listening lessons,<br/>on demand</h1>
            <p className="hero__p">name a topic — get a narrated lesson<br/>in seconds. no account, ever.</p>
          </div>
        ) : (
          <div style={{ height: 18 }} />
        )}

        <div className="fade">
          <CreateForm prefs={prefs} setPrefs={setPrefs} onGo={onGo} compact={!firstRun} />
        </div>

        {!firstRun && library.length > 0 && (
          <div className="fade" style={{ marginTop: 26 }}>
            <div className="section-pad"><div className="lib-head">your echoes</div></div>
            <div className="section-pad" style={{ marginTop: 4, paddingBottom: 28 }}>
              {library.map(e => <EchoRow key={e.id} echo={e} onOpen={onOpenEcho} />)}
            </div>
          </div>
        )}

        {firstRun && (
          <div style={{ height: 28 }} />
        )}
      </div>
    </div>
  );
}

Object.assign(window, { Home });
