/* ============ Echolingo — icons (UI glyphs) ============ */
const Ic = {
  play: (s = 26) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="currentColor">
      <path d="M8 5.5v13a1 1 0 0 0 1.5.87l11-6.5a1 1 0 0 0 0-1.74l-11-6.5A1 1 0 0 0 8 5.5Z"/>
    </svg>
  ),
  pause: (s = 26) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="currentColor">
      <rect x="6.5" y="5" width="4" height="14" rx="1.3"/>
      <rect x="13.5" y="5" width="4" height="14" rx="1.3"/>
    </svg>
  ),
  prev: (s = 22) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="currentColor">
      <path d="M7 6a1 1 0 0 1 2 0v4.3l8.5-5a1 1 0 0 1 1.5.87v11.6a1 1 0 0 1-1.5.87L9 13.7V18a1 1 0 0 1-2 0V6Z"/>
    </svg>
  ),
  next: (s = 22) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="currentColor">
      <path d="M17 6a1 1 0 0 0-2 0v4.3L6.5 5.3A1 1 0 0 0 5 6.17v11.6a1 1 0 0 0 1.5.87L15 13.7V18a1 1 0 0 0 2 0V6Z"/>
    </svg>
  ),
  replay: (s = 24) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.1" strokeLinecap="round" strokeLinejoin="round">
      <path d="M3 12a9 9 0 1 0 2.5-6.2"/>
      <path d="M3 3v4h4"/>
    </svg>
  ),
  chevDown: (s = 18) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M6 9l6 6 6-6"/>
    </svg>
  ),
  check: (s = 16) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round">
      <path d="M5 12.5l4.5 4.5L19 6.5"/>
    </svg>
  ),
  swap: (s = 18) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M7 4L4 7l3 3"/>
      <path d="M4 7h13"/>
      <path d="M17 20l3-3-3-3"/>
      <path d="M20 17H7"/>
    </svg>
  ),
  arrowRight: (s = 18) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M5 12h14"/>
      <path d="M13 6l6 6-6 6"/>
    </svg>
  ),
  spark: (s = 16) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="currentColor">
      <path d="M12 2.5l1.7 5.3a4 4 0 0 0 2.5 2.5L21.5 12l-5.3 1.7a4 4 0 0 0-2.5 2.5L12 21.5l-1.7-5.3a4 4 0 0 0-2.5-2.5L2.5 12l5.3-1.7a4 4 0 0 0 2.5-2.5L12 2.5Z"/>
    </svg>
  ),
  share: (s = 18) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="18" cy="5" r="2.6"/><circle cx="6" cy="12" r="2.6"/><circle cx="18" cy="19" r="2.6"/>
      <path d="M8.3 10.8l7.4-4.3M8.3 13.2l7.4 4.3"/>
    </svg>
  ),
  eye: (s = 18) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round">
      <path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7Z"/>
      <circle cx="12" cy="12" r="2.6"/>
    </svg>
  ),
  eyeOff: (s = 18) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round">
      <path d="M3 3l18 18"/>
      <path d="M10.6 6.2A9.7 9.7 0 0 1 12 6c6.5 0 10 6 10 6a17 17 0 0 1-3 3.6M6.2 7.2A17 17 0 0 0 2 12s3.5 6 10 6a9.4 9.4 0 0 0 3.8-.8"/>
      <path d="M9.9 9.9a2.6 2.6 0 0 0 3.6 3.6"/>
    </svg>
  ),
};
window.Ic = Ic;
