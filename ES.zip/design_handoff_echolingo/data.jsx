/* ============ Echolingo — data ============ */

const LANGUAGES = [
  'English', 'Russian', 'Greek', 'Spanish', 'French', 'Italian',
  'German', 'Portuguese', 'Turkish', 'Dutch', 'Polish', 'Japanese',
  'Korean', 'Mandarin', 'Arabic', 'Hebrew',
];

// CEFR levels (1..6). Level controls difficulty only — pace is the speed control.
const LEVELS = [
  { n: 1, code: 'A1' },
  { n: 2, code: 'A2' },
  { n: 3, code: 'B1' },
  { n: 4, code: 'B2' },
  { n: 5, code: 'C1' },
  { n: 6, code: 'C2' },
];
const cefr = (n) => (LEVELS[(n || 1) - 1] || LEVELS[0]).code;

const SUGGESTIONS = [
  'at the bakery',
  'ordering coffee',
  'checking into a hotel',
  'small talk with a neighbour',
  'at the pharmacy',
  'asking for directions',
];

// ---- the featured / shared echo: a bank dialogue, Greek <- Russian ----
const BANK_LINES = [
  ['Καλημέρα σας, πώς μπορώ να σας βοηθήσω σήμερα;',
   'Доброе утро, чем я могу вам помочь сегодня?'],
  ['Καλημέρα σας, θέλω να ανοίξω έναν λογαριασμό στην τράπεζά σας.',
   'Доброе утро, я хочу открыть счёт в вашем банке.'],
  ['Βεβαίως, μπορούμε να το κάνουμε τώρα, αν έχετε μαζί σας ταυτότητα ή διαβατήριο.',
   'Конечно, мы можем сделать это прямо сейчас, если у вас с собой есть удостоверение личности или паспорт.'],
  ['Έχω μαζί μου το διαβατήριό μου και επίσης έναν λογαριασμό ρεύματος για τη διεύθυνσή μου.',
   'У меня с собой паспорт, а также счёт за электричество с моим адресом.'],
  ['Τέλεια. Τι είδους λογαριασμό θα θέλατε να ανοίξετε;',
   'Отлично. Какой счёт вы хотели бы открыть?'],
  ['Θα ήθελα έναν απλό λογαριασμό ταμιευτηρίου, χωρίς μηνιαία έξοδα.',
   'Я хотел бы простой сберегательный счёт, без ежемесячной платы.'],
  ['Κανένα πρόβλημα. Θα χρειαστεί να συμπληρώσετε αυτή τη φόρμα και να υπογράψετε εδώ.',
   'Никаких проблем. Вам нужно будет заполнить эту форму и расписаться здесь.'],
  ['Μπορώ να καταθέσω και χρήματα στον λογαριασμό σήμερα;',
   'Могу ли я сегодня же положить деньги на счёт?'],
  ['Φυσικά. Μπορείτε να καταθέσετε μετρητά στο ταμείο μόλις ανοίξει ο λογαριασμός.',
   'Конечно. Вы можете внести наличные в кассе, как только счёт будет открыт.'],
  ['Υπέροχα. Σας ευχαριστώ πολύ για τη βοήθεια.',
   'Замечательно. Большое спасибо за помощь.'],
  ['Παρακαλώ. Καλώς ήρθατε στην τράπεζά μας!',
   'Пожалуйста. Добро пожаловать в наш банк!'],
];

const TOTAL = 431; // 7:11
function buildLines(pairs, total) {
  const per = total / pairs.length;
  return pairs.map((p, i) => ({
    target: p[0],
    trans: p[1],
    t: Math.round(i * per),
  }));
}

const FEATURED = {
  id: 'bank-el-ru-l3',
  title: 'Диалог в банке',
  topic: 'диалог в банке',
  learning: 'Greek',
  speak: 'Russian',
  minutes: 5,
  level: 3,
  bilingual: true,
  duration: TOTAL,
  ago: '1d ago',
  lines: buildLines(BANK_LINES, TOTAL),
};

// ---- library for the returning user ----
const LIBRARY = [
  FEATURED,
  { id: 'coffee', title: 'Заказ кофе', learning: 'Greek', speak: 'Russian',
    minutes: 10, level: 2, bilingual: true, duration: 600, ago: '3d ago',
    progress: 1, lines: buildLines(BANK_LINES, 600) },
  { id: 'airport', title: 'В аэропорту', learning: 'Greek', speak: 'Russian',
    minutes: 20, level: 3, bilingual: false, duration: 1200, ago: '1w ago',
    progress: 0.4, lines: buildLines(BANK_LINES, 1200) },
  { id: 'neighbours', title: 'Знакомство с соседями', learning: 'Greek', speak: 'Russian',
    minutes: 5, level: 1, bilingual: true, duration: 300, ago: '2w ago',
    progress: 1, lines: buildLines(BANK_LINES, 300) },
];

function fmtTime(s) {
  s = Math.max(0, Math.floor(s));
  const m = Math.floor(s / 60);
  const sec = String(s % 60).padStart(2, '0');
  return `${m}:${sec}`;
}

Object.assign(window, {
  LANGUAGES, LEVELS, cefr, SUGGESTIONS, FEATURED, LIBRARY, fmtTime,
});
