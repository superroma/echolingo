# Handoff: Echolingo redesign (home / create · player · shared-link landing)

## Overview
Echolingo generates on-demand audio language lessons ("echoes"). You name a topic, pick a
language pair, length, and CEFR level, and get a narrated lesson with a tap-to-navigate
transcript. This package documents a full visual + interaction redesign of the PWA's three
surfaces: the **home/create** screen, the **player**, and the **shared-link landing** (what a
stranger sees when someone shares an echo — engineered to convert them into a user).

## About the Design Files
The files in this bundle are **design references created in HTML/React (via in-browser Babel)** —
prototypes showing the intended look and behavior. They are **not** meant to ship as-is. The task
is to **recreate these designs in your app's existing environment** (your PWA's framework, build,
and component patterns), reusing your established conventions. The HTML is a faithful spec, not a
drop-in.

The prototype also includes two **prototype-only** scaffolds you should NOT port:
- `ios-frame.jsx` — a fake iPhone bezel used only to present the mobile screens. Your real PWA
  renders full-bleed; ignore the bezel, status bar, and home-indicator chrome.
- `tweaks-panel.jsx` — a preview-only control panel for demoing theme/accent/scenario. Not part
  of the product. (The theme + accent logic it drives IS part of the product — see Design Tokens.)

## Fidelity
**High-fidelity.** Final colors, typography, spacing, and interactions. Recreate pixel-faithfully
using your codebase's libraries. Exact values are below.

---

## Design Tokens

### Color — neutral light / dark palettes
The whole UI is driven by CSS custom properties. Ship **two neutral palettes** and switch on the
OS setting (`prefers-color-scheme`), with a manual override (auto / light / dark).

**Light (`:root`, `.theme-light`)**
| Token | Value | Use |
|---|---|---|
| `--paper` | `#F6F6F7` | app background |
| `--paper-2` | `#FFFFFF` | raised surfaces (cards, strips) |
| `--paper-3` | `#FFFFFF` | inputs / control fills |
| `--ink` | `#121214` | primary text |
| `--ink-soft` | `#52525B` | secondary text |
| `--ink-mute` | `#9A9AA3` | tertiary / placeholders / labels |
| `--line` | `#E6E6EA` | hairline borders |
| `--line-soft` | `#EFEFF2` | faint dividers |

**Dark (`.theme-dark`)**
| Token | Value |
|---|---|
| `--paper` | `#0F0F11` |
| `--paper-2` | `#17171A` |
| `--paper-3` | `#202024` |
| `--ink` | `#F3F3F5` |
| `--ink-soft` | `#A6A6AE` |
| `--ink-mute` | `#6C6C75` |
| `--line` | `#2A2A30` |
| `--line-soft` | `#202024` |

### Accent (vibrant, rides on top of either palette)
Default `#F97316` (orange). User-selectable options:
`#FB5A3C` coral · `#2F7BFF` blue · `#0E9F6E` emerald · `#7C5CFF` violet · `#EC4899` pink · `#F97316` orange.
- `--accent` = chosen color; `--accent-ink` = `#FFFFFF` (text on accent).
- The accent ALSO drives the scrubber fill and the current-transcript-line accent
  (`--aegean` is set equal to `--accent`).
- Current-line wash `--aegean-tint` = the accent mixed into the surface:
  `mix(accent, #FFFFFF, 12%)` in light, `mix(accent, #17171A, 24%)` in dark
  (CSS `color-mix(in srgb, var(--accent) 12%, #FFFFFF)` or precompute).

### Typography
Two Google Fonts, both loaded with **Latin + Greek + Cyrillic** subsets (lessons mix scripts):
- **Literata** (serif) — wordmark, screen/lesson titles, hero, the **target-language** transcript
  lines, conversion headline. Weights 400/500/600; italic for taglines/descriptions.
- **IBM Plex Sans** (sans) — all UI chrome, labels, buttons, time, library meta, and the
  **translation** transcript lines. Weights 400/500/600/700.

| Element | Font | Size | Weight | Notes |
|---|---|---|---|---|
| Wordmark "echolingo." | Literata | 21px | 600 | trailing "." uses `--accent` |
| App-bar screen title | Literata | 17px | 600 | centered, ellipsis |
| Topic input / placeholder | Literata | 30px | 400 | multiline, letter-spacing −0.015em |
| Section label (I SPEAK, LENGTH…) | IBM Plex Sans | 12px | 600 | uppercase, letter-spacing 0.12em, `--ink-mute` |
| Library heading "your echoes" | IBM Plex Sans | 12px | 600 | uppercase, 0.12em, `--ink-mute` |
| Library row title | Literata | 18px | 600 | |
| Library row meta | IBM Plex Sans | 13px | 400 | `--ink-mute`; language word in `--accent` |
| Transcript — target line | Literata | 25px × `--fs-scale` | 400 | line-height 1.32 |
| Transcript — translation | IBM Plex Sans | 16px × `--fs-scale` | 400 | `--ink-mute` |
| Hero headline (first-run) | Literata | 34px | 600 | letter-spacing −0.025em |
| Conversion card title | Literata | 30px | 600 | |
| Time / speed / meta | IBM Plex Sans | 13px | 500–600 | tabular-nums for time |

`--fs-scale` is a user text-size multiplier (0.85–1.3) applied to transcript text only.

### Spacing / radius / shadow
- Radii: `--radius:16px`, `--radius-lg:22px`, `--radius-pill:999px`.
- Form section vertical rhythm: ~18px between groups (`margin-bottom`).
- Screen horizontal padding: 22–24px.
- Shadows (light): `--shadow-1: 0 1px 2px rgba(20,20,25,.04), 0 2px 8px rgba(20,20,25,.05)`;
  `--shadow-2: 0 4px 14px rgba(20,20,25,.08), 0 1px 3px rgba(20,20,25,.05)`;
  `--shadow-up: 0 -8px 24px rgba(20,20,25,.07)`. Dark uses heavier `rgba(0,0,0,.3–.4)`.

---

## Screens / Views

### 1. Home / Create (the single create surface)
**Purpose:** name a topic and generate an echo; below it, the user's local library.
**Layout (top→bottom), single scroll column, 22–24px side padding:**
- **App bar** (sticky top): wordmark "echolingo." (left, → home). No "+ new" here — you're already
  on the create surface. (Top padding clears the device status bar in the real PWA's safe-area.)
- **Topic textarea** — borderless, large Literata, auto-grows with content (multiline). Placeholder:
  *"at the bakery, ordering coffee, asking the barista what they recommend…"*.
- **Divider** (1px `--line`).
- **Languages row** — two equal columns: "I SPEAK" select + "LEARNING" select. No swap button.
  Selecting a language that equals the other auto-swaps the two (never collide).
- **Length** — 4 pills: 5 / 10 / 20 / 30 min. Selected pill = filled `--ink` with `--paper-2` text;
  others = `--paper-3` fill + `--line` border, `--ink-soft` text.
- **Level** — label "level · B1" + a range slider, 6 stops, ticks labeled **A1 A2 B1 B2 C1 C2**
  (CEFR). Filled portion = `--accent`. Active tick label = `--accent`. (Level = difficulty ONLY;
  pace is the separate speed control in the player.)
- **go** — accent pill button, Literata 19px, "go →" (arrow icon). Disabled (40% opacity) until the
  topic has text. Centered.
- **"your echoes"** — small uppercase muted label, then the library list (see row spec under
  Components). Hidden when empty.

**First-run variant (new visitor, empty library):** above the form show a hero —
Literata 34px "listening lessons,\non demand" + italic subtext "name a topic — get a narrated
lesson in seconds. no account, ever." On first-run the form also shows topic **suggestion chips**
(see Components). For returning users the form is compact (no chips).

### 2. Player
**Purpose:** listen to an echo; transcript is for navigation, not required reading.
**Layout:** fixed app bar (top) · scrollable transcript (middle) · fixed transport (bottom).
Use a flex column with the middle region `flex:1; min-height:0; overflow:auto` so the transport is
**always fully visible and never clipped** by the device bottom.
- **App bar:** wordmark (→ home) · centered lesson title (Literata, ellipsis) · "+ new" pill (→ home/create).
- **Transcript:** stacked line blocks. Each line = target (Literata, `--ink`) + optional translation
  (IBM Plex Sans, `--ink-mute`). Tap a line to jump playback there.
  - Current line: wash background `--aegean-tint` + a 3px left accent bar (`box-shadow: inset 3px 0 0 var(--accent)`), rounded 16px, generous padding.
  - Past lines: `--ink-soft`. Future lines: `--ink-soft` at 0.72 opacity.
- **Transport (bottom panel):** compact.
  - Scrubber row: thin track (`--line`) with `--accent` fill + small knob; right-aligned time
    `m:ss / m:ss` (tabular). Tap track to seek.
  - Controls row (centered, gap 16): **prev** (48px outline circle) · **play/pause** (62px filled
    `--ink` circle, `--paper-2` glyph) · **next** (48px outline circle). No reload button — reload
    is handled by pull-to-refresh. No extra share/create button here.
  - Speeds row (centered, gap 8): pills **0.75× / 1× / 1.25×** (selected = filled `--ink`), then a
    1px separator, then a **"translation"** toggle pill — filled `--accent` when translations are
    shown, outline when hidden. Only rendered for bilingual echoes.
  - Bottom padding leaves room for the OS home-indicator / safe-area.

### 3. Shared-link landing (player opened from a shared URL by a non-user)
Same player, plus conversion affordances (every echo's URL is deterministic & shareable, no login):
- A **context strip** at the top of the transcript: "a **greek** listening lesson someone shared
  with you · 5 min · B1. press play to listen —" with an inline accent-outline button
  "✦ or make your own →".
- A **conversion card** at the end of the transcript: eyebrow "YOUR TURN" (accent, uppercase),
  Literata title "learn anything, the same way", subtext, a full-width accent CTA
  "✦ make your own echo", and reassurance "free · no account · works offline". Both CTAs → create.

### 4. Generating (transient, ~1.7s after "go")
Centered: spinning ring (3px, top arc = `--accent`), italic "composing your echo…", the topic in
Literata, and a meta line "greek · 5 min · B1".

---

## Components (reusable)
- **Select (custom dropdown):** 54px tall, `--paper-3` fill, `--line` border, radius 16, chevron in
  `--ink-mute`. Opens a menu (radius 16, `--shadow-2`); active item in `--accent`; the other
  language's current value is disabled to prevent collisions.
- **Pill (segmented option):** radius 999, 48px tall; on = `--ink` fill; off = `--paper-3` + border.
- **Suggestion chip:** italic Literata, `--paper-2` fill, `--line` border, radius 999.
- **Echo (library) row:** 44px circular play affordance (outline; shows an `--accent` progress ring
  if partially listened) · title (Literata 18) · meta "‹language› · 5 min · B1 · finished · 1d ago"
  (language word in `--accent`) · trailing `--accent` dot if new/unplayed. Tap → player.
- **Toggle / segmented control ("echo style", "translation"):** small rounded segment group;
  active segment filled.

## Interactions & Behavior
- **Generate:** "go" → Generating screen → after ~1.7s, navigate to player with a new echo prepended
  to the library. Real app: replace the timeout with your generation request + loading state.
- **Language auto-swap:** choosing a language equal to the other field swaps them.
- **Tap-to-jump:** clicking any transcript line seeks playback to that line's start.
- **Auto-scroll:** while playing, keep the current line ~30% from the top of the transcript
  viewport (smooth). Pause auto-scroll for ~2.6s after the user scrolls by hand.
- **Playback (prototype sim):** advances time by `0.2 × speed` every 200ms; replace with real audio
  element + `timeupdate` in production. Current line = last line whose start time ≤ currentTime.
- **prev / next:** jump to previous / next line's start time.
- **Speed:** 0.75 / 1 / 1.25 sets playbackRate.
- **Translation toggle:** show/hide translation lines on bilingual echoes (per-echo; defaults on).
- **Theme:** auto follows `prefers-color-scheme`; manual light/dark override. Apply the palette by
  setting the token block on a root element (class `theme-light` / `theme-dark`) and the accent as
  inline custom properties.
- **Reload:** pull-to-refresh (not a button).

## State Management
- **Preferences (persist):** speak, learning, minutes, level, bilingual (echo style), theme mode,
  accent, text-size scale, last speed.
- **Per-echo (persist):** playback position keyed by echo id (`echo:pos:<id>`), last speed
  (`echo:speed`).
- **Echo identity:** deterministic id from params (`<learning>-<speak>-l<level>-<minutes>-<slug(topic)>`)
  so the same request resolves to the same shareable URL with no login.
- **Per-screen:** route (home / generating / player), current echo, shared-entry flag, library list.

## Design Tokens summary
See the Color / Typography / Spacing tables above; canonical source is `styles.css` (`:root`,
`.theme-light`, `.theme-dark`) and `buildVars()` in `app.jsx` (accent + tint computation).

## Assets
- **Fonts:** Google Fonts "Literata" and "IBM Plex Sans" — request Latin, Greek, and Cyrillic
  subsets. No other image assets; all icons are inline SVG (see `icons.jsx`: play, pause, prev,
  next, chevron, check, arrow, spark, share).
- No raster images, no logos beyond the text wordmark.

## Files in this bundle
Product design references (recreate these):
- `index.html` — entry; font links + script order.
- `styles.css` — all tokens + component styles (the canonical visual spec).
- `app.jsx` — routing, theme/accent application (`buildVars`, `PAL`, `ACCENTS`), generate flow,
  persistence, scenario handling.
- `components.jsx` — AppBar, Select, CreateForm.
- `Home.jsx` — home/create surface + library rows.
- `Player.jsx` — transcript, transport, sim playback, auto-scroll, translation toggle.
- `data.jsx` — sample languages, CEFR levels, sample bilingual transcript, time formatting.
- `icons.jsx` — inline SVG UI glyphs.

Prototype-only (do NOT port): `ios-frame.jsx`, `tweaks-panel.jsx`.

> To preview the reference exactly as designed, open `index.html` from this folder (it still runs
> standalone). Toggle theme/accent/scenario via the Tweaks affordance.
