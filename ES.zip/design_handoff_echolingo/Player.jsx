/* ============ Echolingo — Player screen ============ */

function Player({ echo, shared, onHome, onNew, onCreate, onShareDemo }) {
  const dur = echo.duration;
  const lines = echo.lines;
  const hasTrans = !!echo.bilingual;

  const [t, setT] = useState(() => {
    const saved = +localStorage.getItem('echo:pos:' + echo.id);
    return saved && saved < dur ? saved : 0;
  });
  const [playing, setPlaying] = useState(false);
  const [speed, setSpeed] = useState(() => +localStorage.getItem('echo:speed') || 1);
  const [showTrans, setShowTrans] = useState(hasTrans);
  const displayTrans = hasTrans && showTrans;

  const scrollRef = useRef(null);
  const lineRefs = useRef([]);
  const autoScroll = useRef(true);
  const tRef = useRef(t);
  const speedRef = useRef(speed);
  tRef.current = t; speedRef.current = speed;

  // current line index
  let cur = 0;
  for (let i = 0; i < lines.length; i++) { if (lines[i].t <= t) cur = i; else break; }

  // playback ticker
  useEffect(() => {
    if (!playing) return;
    const id = setInterval(() => {
      setT(prev => {
        const next = prev + 0.2 * speedRef.current;
        if (next >= dur) { setPlaying(false); return dur; }
        return next;
      });
    }, 200);
    return () => clearInterval(id);
  }, [playing, dur]);

  // persist
  useEffect(() => {
    localStorage.setItem('echo:pos:' + echo.id, String(t));
  }, [t, echo.id]);
  useEffect(() => { localStorage.setItem('echo:speed', String(speed)); }, [speed]);

  // auto-scroll the current line into a comfortable reading spot
  const scrollToLine = useCallback((i, smooth) => {
    const el = lineRefs.current[i];
    const box = scrollRef.current;
    if (!el || !box) return;
    const top = el.offsetTop - box.clientHeight * 0.30;
    box.scrollTo({ top, behavior: smooth ? 'smooth' : 'auto' });
  }, []);

  useEffect(() => {
    if (autoScroll.current) scrollToLine(cur, true);
  }, [cur, scrollToLine]);

  // pause auto-scroll briefly when the user scrolls by hand
  useEffect(() => {
    const box = scrollRef.current;
    if (!box) return;
    let timer;
    const onScroll = () => {
      autoScroll.current = false;
      clearTimeout(timer);
      timer = setTimeout(() => { autoScroll.current = true; }, 2600);
    };
    box.addEventListener('wheel', onScroll, { passive: true });
    box.addEventListener('touchmove', onScroll, { passive: true });
    return () => { box.removeEventListener('wheel', onScroll); box.removeEventListener('touchmove', onScroll); };
  }, []);

  const jumpTo = (i) => {
    autoScroll.current = true;
    setT(lines[i].t + 0.01);
    scrollToLine(i, true);
  };
  const replay = () => { autoScroll.current = true; setT(lines[cur].t + 0.01); scrollToLine(cur, true); };
  const prev = () => jumpTo(Math.max(0, cur - 1));
  const next = () => jumpTo(Math.min(lines.length - 1, cur + 1));

  const onScrub = (e) => {
    const r = e.currentTarget.getBoundingClientRect();
    const p = Math.min(1, Math.max(0, (e.clientX - r.left) / r.width));
    autoScroll.current = true;
    setT(p * dur);
  };

  const pct = (t / dur) * 100;

  return (
    <div className="app app--player">
      <AppBar title={echo.title} onHome={onHome} onNew={onNew} />

      <div className="player-scroll" ref={scrollRef}>
      {shared && (
          <div className="share-strip fade">
            <div className="share-strip__txt">
              a <b>{echo.learning.toLowerCase()}</b> listening lesson someone shared with you
              {' '}· {echo.minutes} min · {cefr(echo.level)}. press play to listen —
            </div>
            <button className="share-strip__cta" onClick={onCreate}>
              {Ic.spark(14)} or make your own {Ic.arrowRight(15)}
            </button>
          </div>
        )}

        <div className="transcript">
          {lines.map((ln, i) => {
            const cls = i === cur ? 'is-current' : (i < cur ? 'is-past' : 'is-future');
            return (
              <div key={i} ref={el => lineRefs.current[i] = el}
                className={'line ' + cls} onClick={() => jumpTo(i)}>
                <div className="line__target">{ln.target}</div>
                {displayTrans && <div className="line__trans">{ln.trans}</div>}
              </div>
            );
          })}

          {shared && (
            <div className="convert fade">
              <div className="convert__eyebrow">your turn</div>
              <div className="convert__title">learn anything,<br/>the same way</div>
              <p className="convert__sub">
                echolingo turns any topic into a narrated lesson — your languages, your level,
                ready in seconds. no sign-up required.
              </p>
              <button className="convert__cta" onClick={onCreate}>
                {Ic.spark(16)} make your own echo
              </button>
              <div className="convert__note">free · no account · works offline</div>
            </div>
          )}
        </div>
      </div>

      <div className="transport">
        <div className="scrub-row">
          <div className="scrub" onClick={onScrub}>
            <div className="scrub__track"><div className="scrub__fill" style={{ width: pct + '%' }} /></div>
            <div className="scrub__knob" style={{ left: pct + '%' }} />
          </div>
          <span className="time">{fmtTime(t)} / {fmtTime(dur)}</span>
        </div>

        <div className="controls">
          <button className="ctl ctl--round" onClick={prev} title="previous line">{Ic.prev(20)}</button>
          <button className="ctl ctl--play" onClick={() => setPlaying(p => !p)}>
            {playing ? Ic.pause(26) : Ic.play(26)}
          </button>
          <button className="ctl ctl--round" onClick={next} title="next line">{Ic.next(20)}</button>
        </div>

        <div className="speeds">
          {[0.75, 1, 1.25].map(s => (
            <button key={s} className={'speed' + (speed === s ? ' is-on' : '')} onClick={() => setSpeed(s)}>
              {s}×
            </button>
          ))}
          {hasTrans && (
            <React.Fragment>
              <span className="speeds__sep" />
              <button className={'speed speed--trans' + (showTrans ? ' is-on' : '')}
                onClick={() => setShowTrans(v => !v)}
                title={showTrans ? 'hide translation' : 'show translation'}>
                translation
              </button>
            </React.Fragment>
          )}
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { Player });
