/* ============ Echolingo — app shell ============ */
const { useState: useS, useEffect: useE, useRef: useR } = React;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "themeMode": "auto",
  "accent": "#F97316",
  "fontScale": 1,
  "transcriptMode": "bilingual",
  "scenario": "returning"
}/*EDITMODE-END*/;

/* neutral light / dark palettes. Applied as inline CSS vars on the app wrapper
   (most robust for rendering + capture); accent rides on top. */
const PAL = {
  light: { paper:'#F6F6F7', paper2:'#FFFFFF', paper3:'#FFFFFF',
    ink:'#121214', inkSoft:'#52525B', inkMute:'#9A9AA3',
    line:'#E6E6EA', lineSoft:'#EFEFF2', tintBase:'#FFFFFF', tintW:0.12 },
  dark: { paper:'#0F0F11', paper2:'#17171A', paper3:'#202024',
    ink:'#F3F3F5', inkSoft:'#A6A6AE', inkMute:'#6C6C75',
    line:'#2A2A30', lineSoft:'#202024', tintBase:'#17171A', tintW:0.24 },
};
const ACCENTS = ['#FB5A3C', '#2F7BFF', '#0E9F6E', '#7C5CFF', '#EC4899', '#F97316'];

function hx(h) { h = h.replace('#',''); return [0,2,4].map(i => parseInt(h.slice(i,i+2),16)); }
function mixHex(a, b, wA) {
  const A = hx(a), B = hx(b);
  const c = i => Math.round(A[i]*wA + B[i]*(1-wA)).toString(16).padStart(2,'0');
  return '#' + c(0) + c(1) + c(2);
}
function buildVars(isDark, accent, fontScale) {
  const p = isDark ? PAL.dark : PAL.light;
  return {
    '--paper': p.paper, '--paper-2': p.paper2, '--paper-3': p.paper3,
    '--ink': p.ink, '--ink-soft': p.inkSoft, '--ink-mute': p.inkMute,
    '--line': p.line, '--line-soft': p.lineSoft,
    '--accent': accent, '--accent-ink': '#FFFFFF',
    '--aegean': accent, '--aegean-tint': mixHex(accent, p.tintBase, p.tintW),
    '--fs-scale': fontScale,
    height: '100%', position: 'relative',
  };
}

function slug(s) {
  return s.toLowerCase().trim().replace(/[^a-zа-яёα-ω0-9]+/gi, '-').replace(/^-|-$/g, '').slice(0, 40);
}
function timed(lines, dur) {
  const per = dur / lines.length;
  return lines.map((l, i) => ({ ...l, t: Math.round(i * per) }));
}

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);

  const [prefs, setPrefs] = useS({
    topic: '', speak: 'Russian', learning: 'Greek',
    minutes: 5, level: 3, bilingual: true,
  });

  const [screen, setScreen] = useS('home');   // home | create | generating | player
  const [echo, setEcho] = useS(FEATURED);
  const [shared, setShared] = useS(false);     // is current player the shared-landing view
  const [library, setLibrary] = useS(LIBRARY);
  const [firstRun, setFirstRun] = useS(false); // brand-new visitor (no library yet)
  const [toast, setToast] = useS(null);

  // react to scenario tweak
  useE(() => {
    if (t.scenario === 'shared') {
      setLibrary([]); setFirstRun(true);
      setEcho(FEATURED); setShared(true); setScreen('player');
    } else {
      setLibrary(LIBRARY); setFirstRun(false);
      setShared(false); setScreen('home');
    }
  }, [t.scenario]);

  // follow the phone's appearance when mode is "auto"
  const [sysDark, setSysDark] = useS(() =>
    window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches);
  useE(() => {
    if (!window.matchMedia) return;
    const mq = window.matchMedia('(prefers-color-scheme: dark)');
    const h = (e) => setSysDark(e.matches);
    mq.addEventListener ? mq.addEventListener('change', h) : mq.addListener(h);
    return () => { mq.removeEventListener ? mq.removeEventListener('change', h) : mq.removeListener(h); };
  }, []);

  const isDark = t.themeMode === 'dark' || (t.themeMode === 'auto' && sysDark);

  // mirror theme onto <html> so the behind-bezel backdrop matches
  useE(() => {
    document.documentElement.className = isDark ? 'theme-dark' : 'theme-light';
  }, [isDark]);

  const flash = (msg) => { setToast(msg); clearTimeout(window.__tt); window.__tt = setTimeout(() => setToast(null), 2400); };

  const goHome = () => { setShared(false); setScreen('home'); };

  const generate = () => {
    const topic = prefs.topic.trim() || 'at the bakery';
    const dur = prefs.minutes * 60;
    const id = `${prefs.learning}-${prefs.speak}-l${prefs.level}-${prefs.minutes}-${slug(topic)}`.toLowerCase();
    const made = {
      id, title: topic.charAt(0).toUpperCase() + topic.slice(1),
      learning: prefs.learning, speak: prefs.speak,
      minutes: prefs.minutes, level: prefs.level, bilingual: prefs.bilingual,
      duration: dur, ago: 'just now', progress: 0,
      lines: timed(FEATURED.lines, dur),
    };
    setScreen('generating');
    setTimeout(() => {
      setEcho(made); setShared(false); setFirstRun(false);
      setLibrary(lib => [made, ...lib.filter(e => e.id !== id)]);
      setScreen('player');
    }, 1700);
  };

  const openEcho = (e) => { setEcho(e); setShared(false); setScreen('player'); };
  const createFromShare = () => { setShared(false); setScreen('home'); };
  // returning-user "share" button: preview what a recipient sees
  const shareDemo = () => { flash('link copied — this is what they\u2019ll see'); setShared(true); setScreen('player'); };

  let view;
  if (screen === 'generating') {
    view = (
      <div className="app">
        <AppBar onHome={goHome} />
        <div className="gen">
          <div className="gen__ring" />
          <div>
            <div className="gen__txt" style={{ marginBottom: 8 }}>composing your echo…</div>
            <div className="gen__topic">{prefs.topic.trim() || 'at the bakery'}</div>
            <div className="gen__txt" style={{ marginTop: 10, fontSize: 14 }}>
              {prefs.learning.toLowerCase()} · {prefs.minutes} min · {cefr(prefs.level)}
            </div>
          </div>
        </div>
      </div>
    );
  } else if (screen === 'player') {
    view = <Player echo={echo} shared={shared}
      onHome={goHome} onNew={goHome} onCreate={createFromShare} onShareDemo={shareDemo} />;
  } else {
    view = <Home prefs={prefs} setPrefs={setPrefs} onGo={generate}
      onOpenEcho={openEcho} onHome={goHome} library={library} firstRun={firstRun} />;
  }

  return (
    <div className={isDark ? 'theme-dark' : 'theme-light'}
      style={buildVars(isDark, t.accent, t.fontScale)}>
      {view}
      {toast && <div className="toast fade">{toast}</div>}

      <TweaksPanel>
        <TweakSection label="Appearance" />
        <TweakRadio label="Theme" value={t.themeMode}
          options={['auto', 'light', 'dark']}
          onChange={(v) => setTweak('themeMode', v)} />
        <div style={{ font: '12px/1.45 var(--font-sans)', color: '#6b6458', padding: '0 2px 4px' }}>
          “auto” follows the phone’s light/dark setting.
        </div>

        <TweakSection label="Accent" />
        <TweakColor label="Color" value={t.accent}
          options={ACCENTS}
          onChange={(v) => setTweak('accent', v)} />

        <TweakSection label="Reading" />
        <TweakSlider label="Text size" value={t.fontScale} min={0.85} max={1.3} step={0.05}
          onChange={(v) => setTweak('fontScale', v)} />

        <TweakSection label="Scenario" />
        <TweakRadio label="Open as" value={t.scenario}
          options={['returning', 'shared']}
          onChange={(v) => setTweak('scenario', v)} />
        <div style={{ font: '12px/1.45 var(--font-sans)', color: '#6b6458', padding: '2px 2px 6px' }}>
          “shared” = a stranger opening your link. Watch how the create path is surfaced.
        </div>
      </TweaksPanel>
    </div>
  );
}

/* ---- mount in iOS frame with scale-to-fit ---- */
function Root() {
  const [scale, setScale] = useS(1);
  useE(() => {
    const W = 402, H = 874, pad = 28;
    const fit = () => {
      const s = Math.min((window.innerWidth - pad) / W, (window.innerHeight - pad) / H, 1.12);
      setScale(s);
    };
    fit();
    window.addEventListener('resize', fit);
    return () => window.removeEventListener('resize', fit);
  }, []);
  return (
    <div id="scaler" style={{ transform: `scale(${scale})` }}>
      <IOSDevice>
        <App />
      </IOSDevice>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('stage')).render(<Root />);
